﻿namespace pensionato
{
    class Locatario
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public int Room { get; set; }
    }
}
